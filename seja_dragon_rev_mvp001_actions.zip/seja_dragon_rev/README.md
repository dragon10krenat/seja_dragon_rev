# Seja — Dragon Revival (Dragon Build #001)

**Status:** MVP scaffolding (Flutter).  
**Style:** Neon-Arabic dark theme.  
**Modes:** Local vs AI (Easy/Medium), Tutorial page, Home.

## Quick Start
```bash
# 1) Make sure you have Flutter installed (3.22+ recommended)
flutter --version

# 2) Unzip this project and enter its folder
cd seja_dragon_rev

# 3) Create platform folders (android/ios/web/macos/windows) if absent
flutter create .

# 4) Get packages
flutter pub get

# 5) Run on your device/emulator
flutter run
```

## Notes
- This MVP build is **offline** (no Firebase yet). Online play will land in Build #002+.
- Arabic (RTL) is enabled by default; English available as fallback.
- AI currently includes Easy/Medium (depth-limited minimax).

## Next Sprints
- Build #002: Online lobby (Firebase), presence, rematch.
- Build #003: Improved AI (alpha-beta, heuristics), animations, SFX.


---

## Phone-only build (no PC) via GitHub Actions

You can build an installable APK on your phone using GitHub:

1) Create a new empty repo on GitHub (name: `seja_dragon_rev`).
2) Upload all files from this folder (use GitHub mobile app or web).
3) Go to the repo → **Actions** tab → enable Actions if asked.
4) Run the workflow **Android Debug APK (Flutter)** (`Run workflow` button).
5) Wait 5–10 minutes → open the workflow run → **Artifacts** → download `seja-dragon-debug-apk` → `app-debug.apk`.
6) Install `app-debug.apk` on your Android phone.
