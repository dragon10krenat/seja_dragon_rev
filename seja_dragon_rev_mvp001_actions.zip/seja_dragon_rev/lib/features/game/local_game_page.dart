import 'package:flutter/material.dart';
import '../../core/board.dart';
import '../../core/rules.dart';
import '../../core/ai/minimax.dart';
import 'widgets/board_view.dart';

class LocalGamePage extends StatefulWidget {
  const LocalGamePage({super.key});

  @override
  State<LocalGamePage> createState() => _LocalGamePageState();
}

class _LocalGamePageState extends State<LocalGamePage> {
  BoardState s = BoardState.initial();
  final ai = const MiniMaxAI(depth: 2); // Easy/Medium
  int? selectedIndex;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مباراة محلية')),
      body: Column(
        children: [
          const SizedBox(height: 12),
          Text(
            s.phase == Phase.place
              ? (s.whiteTurn ? 'دور الأبيض (وضع حجر)' : 'دور الأسود (وضع حجر)')
              : (s.whiteTurn ? 'دور الأبيض (تحريك)' : 'دور الأسود (تحريك)'),
          ),
          Expanded(
            child: Center(
              child: BoardView(state: s, onTap: _onTap),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(onPressed: _reset, child: const Text('إعادة')),
                ElevatedButton(onPressed: _aiMove, child: const Text('حركة الذكاء')),
              ],
            ),
          )
        ],
      ),
    );
  }

  void _reset() => setState(() => s = BoardState.initial());

  void _onTap(int index) {
    setState(() {
      if (s.phase == Phase.place) {
        if (Rules.canPlace(s, index)) {
          s = s.placeAt(index);
        }
        return;
      }
      // move phase
      if (selectedIndex == null) {
        // select a piece
        final cell = s.cells[index];
        if (s.whiteTurn && cell == Cell.w) { selectedIndex = index; }
        if (!s.whiteTurn && cell == Cell.b) { selectedIndex = index; }
      } else {
        // attempt move
        final from = selectedIndex!;
        final next = Rules.move(s, from, index);
        if (!identical(next, s)) {
          s = next;
        }
        selectedIndex = null;
      }
    });
  }

  void _aiMove() {
    setState(() {
      if (s.phase == Phase.place) {
        final idx = ai.chooseMove(s);
        if (idx >= 0) s = s.placeAt(idx);
        return;
      }
      final code = ai.chooseMove(s);
      if (code < 0) return;
      final from = code ~/ 100;
      final to = code % 100;
      s = Rules.move(s, from, to);
    });
  }
}
