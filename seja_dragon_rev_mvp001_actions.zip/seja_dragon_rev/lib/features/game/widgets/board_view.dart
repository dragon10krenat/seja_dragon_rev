import 'package:flutter/material.dart';
import '../../../theme/colors.dart';
import '../../../core/board.dart';

class BoardView extends StatelessWidget {
  final BoardState state;
  final void Function(int index) onTap;
  const BoardView({super.key, required this.state, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1,
      child: GridView.builder(
        padding: const EdgeInsets.all(8),
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 5),
        itemCount: 25,
        itemBuilder: (_, i) {
          final c = state.cells[i];
          return InkWell(
            onTap: () => onTap(i),
            child: Container(
              margin: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: AppColors.surface,
                border: Border.all(color: AppColors.border),
                borderRadius: BorderRadius.circular(10),
                boxShadow: const [BoxShadow(blurRadius: 6, spreadRadius: 0.5, color: Colors.black54)],
              ),
              child: Center(
                child: switch (c) {
                  Cell.w => _stone(Colors.white),
                  Cell.b => _stone(Colors.black),
                  _ => const SizedBox.shrink(),
                },
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _stone(Color base) => Container(
    width: 28, height: 28,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      color: base,
      boxShadow: const [
        BoxShadow(blurRadius: 18, color: AppColors.primary),
      ],
    ),
  );
}
