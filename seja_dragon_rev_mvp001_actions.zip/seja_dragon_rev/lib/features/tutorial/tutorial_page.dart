import 'package:flutter/material.dart';

class TutorialPage extends StatelessWidget {
  const TutorialPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تعلّم القواعد')),
      body: const Padding(
        padding: EdgeInsets.all(16.0),
        child: Text(
          'قواعد سيجة (Seja):\n'
          '1) مرحلة التوزيع: يضع كل لاعب أحجاره بالتناوب على شبكة 5×5 حتى تنتهي الأحجار.\n'
          '2) مرحلة التحريك: يحرّك اللاعب حجره خطوة واحدة عموديًا أو أفقيًا إلى خانة فارغة.\n'
          '3) الأسر بالمحاصرة: إذا أصبحت قطعة الخصم بين قطعتين من قطعك في خط مستقيم (يمين/يسار أو أعلى/أسفل)، تُؤسر وتُزال.\n'
          'الهدف: أسر أكبر عدد من أحجار الخصم حتى يتعذّر عليه الحركة أو يفقد أغلب أحجاره.',
          textAlign: TextAlign.start,
        ),
      ),
    );
  }
}
