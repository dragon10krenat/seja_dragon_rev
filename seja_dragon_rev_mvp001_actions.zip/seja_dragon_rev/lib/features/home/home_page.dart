import 'package:flutter/material.dart';
import '../../theme/colors.dart';
import '../game/local_game_page.dart';
import '../tutorial/tutorial_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [AppColors.bg, AppColors.surface],
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 20),
            Text('Seja — Dragon Revival',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                )),
            const SizedBox(height: 8),
            const Text('سيجة الحديثة — أسلوب نيون عربي', textAlign: TextAlign.center),
            const SizedBox(height: 24),
            _btn(context, 'بدء مباراة محلية', const LocalGamePage()),
            _btn(context, 'تدريب / تعلّم القواعد', const TutorialPage()),
            const SizedBox(height: 40),
            const Text('Build #001 • MVP', style: TextStyle(color: Colors.white70)),
          ],
        ),
      ),
    );
  }

  Widget _btn(BuildContext context, String title, Widget page) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: ElevatedButton(
        onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => page)),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
          child: Text(title),
        ),
      ),
    );
  }
}
