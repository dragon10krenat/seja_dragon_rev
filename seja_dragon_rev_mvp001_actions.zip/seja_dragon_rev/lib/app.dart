import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'theme/colors.dart';
import 'features/home/home_page.dart';

class SejaDragonApp extends StatelessWidget {
  const SejaDragonApp({super.key});

  @override
  Widget build(BuildContext context) {
    final textTheme = GoogleFonts.cairoTextTheme();
    final theme = ThemeData(
      brightness: Brightness.dark,
      useMaterial3: true,
      scaffoldBackgroundColor: AppColors.bg,
      colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primary, brightness: Brightness.dark),
      textTheme: textTheme.apply(bodyColor: Colors.white, displayColor: Colors.white),
    );
    return MaterialApp(
      title: 'Seja — Dragon Revival',
      debugShowCheckedModeBanner: false,
      theme: theme,
      home: const HomePage(),
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
    );
  }
}
