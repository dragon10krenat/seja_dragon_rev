import 'package:flutter/material.dart';

class AppColors {
  static const Color bg = Color(0xFF0E0E12);
  static const Color surface = Color(0xFF15151C);
  static const Color border = Color(0xFF2A2A34);
  static const Color primary = Color(0xFFFF1493); // Hot Pink
  static const Color secondary = Color(0xFF10D7E2); // Cyan
  static const Color amber = Color(0xFFFFC857);
  static const Color green = Color(0xFF15E38A);
}
