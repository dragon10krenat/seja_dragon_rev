enum Cell { e, w, b } // empty, white, black
enum Phase { place, move }

class BoardState {
  final List<Cell> cells; // length 25
  final bool whiteTurn;
  final Phase phase;
  final int whiteToPlace;
  final int blackToPlace;

  const BoardState._(this.cells, this.whiteTurn, this.phase, this.whiteToPlace, this.blackToPlace);

  factory BoardState.initial({int stonesPerSide = 12}) {
    return BoardState._(List<Cell>.filled(25, Cell.e), true, Phase.place, stonesPerSide, stonesPerSide);
  }

  Cell cellAt(int index) => cells[index];

  BoardState setCell(int index, Cell v) {
    final n = List<Cell>.from(cells);
    n[index] = v;
    return BoardState._(n, whiteTurn, phase, whiteToPlace, blackToPlace);
  }

  BoardState toggleTurn() => BoardState._(cells, !whiteTurn, phase, whiteToPlace, blackToPlace);

  BoardState setPhase(Phase p) => BoardState._(cells, whiteTurn, p, whiteToPlace, blackToPlace);

  BoardState placeAt(int index) {
    if (cells[index] != Cell.e) return this;
    final n = List<Cell>.from(cells);
    n[index] = whiteTurn ? Cell.w : Cell.b;
    final wRem = whiteTurn ? (whiteToPlace - 1) : whiteToPlace;
    final bRem = whiteTurn ? blackToPlace : (blackToPlace - 1);
    final nextPhase = (wRem == 0 && bRem == 0) ? Phase.move : phase;
    return BoardState._(n, !whiteTurn, nextPhase, wRem, bRem);
  }

  bool get isBoardFull => !cells.contains(Cell.e);
}
