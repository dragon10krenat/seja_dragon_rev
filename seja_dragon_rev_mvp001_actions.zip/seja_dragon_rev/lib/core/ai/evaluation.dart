import '../board.dart';

class Evaluation {
  static double score(BoardState s) {
    // Basic heuristic: piece diff + center control + mobility
    int w = 0, b = 0;
    for (final c in s.cells) {
      if (c == Cell.w) w++;
      if (c == Cell.b) b++;
    }
    final diff = (s.whiteTurn ? (w - b) : (b - w)).toDouble();

    double center = 0;
    const centerIdx = 12; // 2,2
    final cCenter = s.cells[centerIdx];
    if (cCenter != Cell.e) {
      center = (cCenter == (s.whiteTurn ? Cell.w : Cell.b)) ? 0.6 : -0.6;
    }
    // mobility: count empty neighbors around current side's pieces
    int mobility = 0;
    for (int i = 0; i < 25; i++) {
      final c = s.cells[i];
      if (s.whiteTurn && c != Cell.w) continue;
      if (!s.whiteTurn && c != Cell.b) continue;
      mobility += _emptyNeighbors(s, i);
    }
    return diff + center + mobility * 0.03;
  }

  static int _emptyNeighbors(BoardState s, int idx) {
    final r = idx ~/ 5;
    final c = idx % 5;
    int count = 0;
    void chk(int rr, int cc) {
      if (rr < 0 || rr >= 5 || cc < 0 || cc >= 5) return;
      if (s.cells[rr * 5 + cc] == Cell.e) count++;
    }
    chk(r - 1, c); chk(r + 1, c); chk(r, c - 1); chk(r, c + 1);
    return count;
  }
}
