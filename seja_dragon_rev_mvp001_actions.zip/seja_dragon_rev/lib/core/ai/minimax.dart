import '../board.dart';
import '../rules.dart';
import 'package:flutter/foundation.dart';
import 'evaluation.dart';

class MiniMaxAI {
  final int depth;

  const MiniMaxAI({this.depth = 2});

  int chooseMove(BoardState s) {
    // Only used in move phase; for place phase we pick best empty heuristically
    if (s.phase == Phase.place) {
      return _bestPlacementIndex(s);
    }
    // For move phase, iterate over all pieces and their legal moves
    double bestScore = -1e9;
    int? bestFrom;
    int? bestTo;
    for (int i = 0; i < 25; i++) {
      final cell = s.cells[i];
      if (s.whiteTurn && cell != Cell.w) continue;
      if (!s.whiteTurn && cell != Cell.b) continue;
      final moves = Rules.legalMoves(s, i);
      for (final to in moves) {
        final after = Rules.move(s, i, to);
        final score = _minimax(after, depth - 1, false, -1e9, 1e9);
        if (score > bestScore) {
          bestScore = score;
          bestFrom = i;
          bestTo = to;
        }
      }
    }
    // Encode as index: from*100 + to (simple packing)
    if (bestFrom == null || bestTo == null) return -1;
    return bestFrom * 100 + bestTo;
  }

  int _bestPlacementIndex(BoardState s) {
    // Greedy placement: prefer center and empty neighbors
    double best = -1e9;
    int bestIdx = -1;
    for (int i = 0; i < 25; i++) {
      if (s.cells[i] != Cell.e) continue;
      final r = i ~/ 5;
      final c = i % 5;
      final centerBonus = (r == 2 && c == 2) ? 1.0 : 0.0;
      final mobility = _emptyNeighbors(s, i) * 0.1;
      final score = centerBonus + mobility;
      if (score > best) {
        best = score;
        bestIdx = i;
      }
    }
    return bestIdx;
  }

  int _emptyNeighbors(BoardState s, int idx) {
    final r = idx ~/ 5;
    final c = idx % 5;
    int count = 0;
    void chk(int rr, int cc) {
      if (rr < 0 || rr >= 5 || cc < 0 || cc >= 5) return;
      if (s.cells[rr * 5 + cc] == Cell.e) count++;
    }
    chk(r - 1, c); chk(r + 1, c); chk(r, c - 1); chk(r, c + 1);
    return count;
  }

  double _minimax(BoardState s, int d, bool maximizing, double alpha, double beta) {
    if (d == 0) return Evaluation.score(s);
    // generate pseudo-moves for both sides
    double best = maximizing ? -1e9 : 1e9;
    for (int i = 0; i < 25; i++) {
      final cell = s.cells[i];
      if (s.whiteTurn && cell != Cell.w) continue;
      if (!s.whiteTurn && cell != Cell.b) continue;
      for (final to in Rules.legalMoves(s, i)) {
        final after = Rules.move(s, i, to);
        final val = _minimax(after, d - 1, !maximizing, alpha, beta);
        if (maximizing) {
          if (val > best) best = val;
          if (best > alpha) alpha = best;
        } else {
          if (val < best) best = val;
          if (best < beta) beta = best;
        }
        if (beta <= alpha) return best;
      }
    }
    return best == (maximizing ? -1e9 : 1e9) ? Evaluation.score(s) : best;
  }
}
