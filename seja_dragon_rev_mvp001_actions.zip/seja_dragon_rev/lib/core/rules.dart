import 'board.dart';

class Rules {
  static bool canPlace(BoardState s, int index) {
    return s.phase == Phase.place && s.cells[index] == Cell.e;
  }

  static List<int> legalMoves(BoardState s, int fromIndex) {
    // Moves are 4-neighborhood (up/down/left/right) by 1 step in move phase
    if (s.phase != Phase.move) return const [];
    final c = s.cells[fromIndex];
    if ((s.whiteTurn && c != Cell.w) || (!s.whiteTurn && c != Cell.b)) return const [];
    final r = fromIndex ~/ 5;
    final cIdx = fromIndex % 5;
    final moves = <int>[];
    void tryAdd(int rr, int cc) {
      if (rr < 0 || rr >= 5 || cc < 0 || cc >= 5) return;
      final to = rr * 5 + cc;
      if (s.cells[to] == Cell.e) moves.add(to);
    }
    tryAdd(r - 1, cIdx);
    tryAdd(r + 1, cIdx);
    tryAdd(r, cIdx - 1);
    tryAdd(r, cIdx + 1);
    return moves;
  }

  static BoardState move(BoardState s, int fromIndex, int toIndex) {
    if (s.phase != Phase.move) return s;
    final piece = s.cells[fromIndex];
    if (piece == Cell.e) return s;
    final legal = legalMoves(s, fromIndex);
    if (!legal.contains(toIndex)) return s;

    final n = List<Cell>.from(s.cells);
    n[fromIndex] = Cell.e;
    n[toIndex] = piece;
    var next = BoardState._(n, s.whiteTurn, s.phase, s.whiteToPlace, s.blackToPlace);

    // capture by sandwich (left-right / up-down)
    next = _applyCaptures(next, toIndex);
    return next.toggleTurn();
  }

  static BoardState _applyCaptures(BoardState s, int at) {
    final r = at ~/ 5;
    final c = at % 5;
    final me = s.cells[at];
    final opp = (me == Cell.w) ? Cell.b : Cell.w;
    final n = List<Cell>.from(s.cells);

    void checkLine(int r1, int c1, int r2, int c2) {
      final a = (r1 < 0 || r1 >= 5 || c1 < 0 || c1 >= 5) ? null : s.cells[r1 * 5 + c1];
      final b = (r2 < 0 || r2 >= 5 || c2 < 0 || c2 >= 5) ? null : s.cells[r2 * 5 + c2];
      if (a == opp && b == me) n[r1 * 5 + c1] = Cell.e;
      if (b == opp && a == me) n[r2 * 5 + c2] = Cell.e;
    }

    checkLine(r, c - 1, r, c + 1); // left-right
    checkLine(r - 1, c, r + 1, c); // up-down

    return BoardState._(n, s.whiteTurn, s.phase, s.whiteToPlace, s.blackToPlace);
  }
}
